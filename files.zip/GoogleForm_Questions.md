# IRO Feasibility Questionnaire — Google Form Content

Copy these questions into a new Google Form (forms.google.com). Two respondent groups are
captured with one **first question** that branches the rest of the form using Google Forms'
"Go to section based on answer" feature.

**Form title:** IRO — Issues Reporting Outlet: Community Feasibility Survey
**Form description:** This short survey helps us understand issues between AAUA students and
residents of Akungba, Iwaro, Etioro, and Ayegunle, so we can design a fair, useful reporting system.
Your answers are anonymous unless you choose to share contact details.

---

## Section 1 — Who you are
1. **Are you a...** *(Multiple choice — branches the form)*
   - AAUA Student → go to Section 2 (Student)
   - Indigene of a host community → go to Section 3 (Indigene)

2. **Which community are you most associated with?** *(Dropdown)*
   - Akungba / Iwaro / Etioro / Ayegunle / Other

3. **Age range** *(Multiple choice)*: Under 18 / 18–25 / 26–35 / 36–50 / Above 50

---

## Section 2 — For Students
4. Have you personally experienced or witnessed an issue/conflict with an indigene of your host community? *(Yes / No / Not sure)*
5. If yes, what type of issue was it? *(Checkboxes — allow multiple)*
   - Land/Property · Harassment · Noise/Disturbance · Rent/Utility dispute · Security · Other
6. Was the issue ever formally reported to anyone (e.g., student affairs, community leader)? *(Yes / No)*
7. If not reported, why not? *(Checkboxes)*
   - Didn't know who to report to · Feared victimization · Didn't think it would be resolved · Not serious enough · Other
8. How would you prefer to report an issue in future? *(Multiple choice)*
   - A website/web app · A phone call/SMS line · In person to an office · WhatsApp/Social media
9. On a scale of 1–5, how useful would a dedicated web platform (like IRO) be to you? *(Linear scale 1–5)*
10. Any additional comments? *(Paragraph, optional)*

---

## Section 3 — For Indigenes
4. Have you personally experienced or witnessed an issue/conflict with an AAUA student? *(Yes / No / Not sure)*
5. If yes, what type of issue was it? *(Checkboxes)*
   - Land/Property · Harassment · Noise/Disturbance · Rent/Utility dispute · Security · Other
6. Was the issue ever formally reported to anyone (e.g., community leader, university office)? *(Yes / No)*
7. If not reported, why not? *(Checkboxes)*
   - Didn't know who to report to · Feared confrontation · Didn't think it would be resolved · Not serious enough · Other
8. How would you prefer to report an issue in future? *(Multiple choice)*
   - A website/web app · A phone call/SMS line · In person to an office · WhatsApp/Social media
9. On a scale of 1–5, how useful would a dedicated web platform (like IRO) be to you? *(Linear scale 1–5)*
10. Any additional comments? *(Paragraph, optional)*

---

## Section 4 — Optional contact (both groups)
11. Would you like to be contacted about the outcome of issues you report? *(Yes / No)*
12. If yes, phone or email *(Short answer, optional)*

---

### Notes for building this in Google Forms
- Use **Settings → make this a quiz: off**, and turn on "Collect email addresses: off" to keep it anonymous by default.
- Use **Sections** (the "≡" icon) for Section 2 vs Section 3, and set Question 1's branching under the three-dot menu → "Go to section based on answer."
- Export responses to Sheets, and add a screenshot or the response summary link into your SRS appendix once you have a few responses.
