# IRO — Issues Reporting Outlet
**CSC426 Weekend 3 Development Exercise — Submission Package**

A web-based system for relating and reporting issues concerning AAUA students and the
indigenes of host communities (Akungba, Iwaro, Etioro, Ayegunle).

## Contents of this repository

| File | Assignment item | Description |
|---|---|---|
| `GoogleForm_Questions.md` | (a) Questionnaire | Content to paste into a Google Form; captures issues from both students and indigenes |
| `IRO_Ishikawa_Diagram.svg` | (b) Ishikawa analysis | Fishbone diagram of root causes of unresolved/poorly reported issues |
| `webapp/index.html` | (c) Mini web interface | Single-file working prototype: submit report, track by reference number, admin dashboard |
| `IRO_UseCase_Diagram.svg` | (d) Use-case diagram | Student, Indigene, and Administrator actors and their interactions with the system |
| `IRO_SRS.docx` | (e) SRS document | Full Software Requirements Specification, functional & non-functional requirements |

## Running the mini web interface

No build step or server required — it's a single static HTML file with inline CSS/JS.

```bash
# open directly in a browser
open webapp/index.html      # macOS
start webapp\index.html     # Windows
```

Data is held in memory for the demo (resets on page reload), keeping the prototype simple as
instructed. The three tabs are:
- **Report** — submit an issue, get a reference number
- **Track** — check a report's status by reference number
- **Admin** — view all reports, filter/inspect, and update status

## Submission checklist (per the assignment brief)
- [x] Google Form questionnaire content drafted — build the live form from `GoogleForm_Questions.md`
- [x] Ishikawa diagram (`IRO_Ishikawa_Diagram.svg`)
- [x] Mini web interface (`webapp/index.html`)
- [x] Use-case diagram (`IRO_UseCase_Diagram.svg`)
- [x] SRS document (`IRO_SRS.docx`)
- [ ] Push this repo to your own GitHub account
- [ ] Email the repo link to **ajsoftengr@gmail.com** before Friday, 10th July 2026
- [ ] After acknowledgment, print (font size 10) the SRS, use-case diagram, Ishikawa diagram,
      object listing, and code listing for physical submission in your "on the way" manual
